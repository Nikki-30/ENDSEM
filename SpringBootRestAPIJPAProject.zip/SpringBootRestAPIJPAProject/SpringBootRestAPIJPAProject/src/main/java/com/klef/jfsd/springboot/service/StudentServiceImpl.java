package com.klef.jfsd.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.Repository;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Student;
import com.klef.jfsd.springboot.repository.StudentRepository;
@Service

public class StudentServiceImpl implements StudentService{
 @Autowired
	private StudentRepository repoistory;
	
	
	@Override
	public String addstudent(Student s) {
		
		repoistory.save(s);
		return "Student added successfully";
	}

	@Override
	public String updatestudent(Student s) {
		Optional<Student> object = repoistory.findById(s.getId());
		String msg=null;
		
		if(object.isPresent()) {
			Student student=object.get();
			
			
			student.setAge(s.getAge());
			student.setContact(s.getContact());
			student.setDepartment(s.getDepartment());
			student.setEmail(s.getEmail());
			student.setGender(s.getGender());
			student.setName(s.getName());
			
			repoistory.save(student);
			
			msg="Student Updated Successfully";
			
		}
		else {
			msg="Student ID not Found";
		}
		return msg;
	}

	@Override
	public String deletestudent(int sid) {
		Optional<Student> object = repoistory.findById(sid);
		String msg=null;
		
		if(object.isPresent()) {
			Student s=object.get();
			repoistory.delete(s);
			msg="Student Deleted Successfully";
		}
		else {
			msg="Student ID not found";
		}
		return msg;
	}

	@Override
	public Student viewstudentbyid(int sid) {
		
		return repoistory.findById(sid).get();
	}

	@Override
	public List<Student> viewallstudents() {
		return (List<Student>) repoistory.findAll();
	}

}
